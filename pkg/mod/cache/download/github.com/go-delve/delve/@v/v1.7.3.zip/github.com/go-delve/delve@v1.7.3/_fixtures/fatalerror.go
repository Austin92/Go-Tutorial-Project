package main

func main() {
	var f func()
	go f()
}
